Command line used to find this crash:

/home/angr/.virtualenvs/angr/bin/afl-cgc/afl-fuzz -i /dev/shm/work/CROMU_00006_adv/input -o /dev/shm/work/CROMU_00006_adv/sync -m 8G -Q -S fuzzer-1 -x /dev/shm/work/CROMU_00006_adv/CROMU_00006_adv.dict -- /home/angr/testcase/cgc_adv/CROMU_00006_adv

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 8.00 GB.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
me a mail at <lcamtuf@coredump.cx> once the issues are fixed - I'd love to
add your finds to the gallery at:

  http://lcamtuf.coredump.cx/afl/

Thanks :-)
